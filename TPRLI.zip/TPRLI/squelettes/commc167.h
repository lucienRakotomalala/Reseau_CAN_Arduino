
void init_ASC0_384(void);
void putchar_console(char c);
void puts_console(char *chaine);
void printf_entier_console(char* mess, int var);




